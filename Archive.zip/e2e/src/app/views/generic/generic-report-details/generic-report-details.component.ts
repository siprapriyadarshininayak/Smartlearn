import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generic-report-details',
  templateUrl: './generic-report-details.component.html',
  styleUrls: ['./generic-report-details.component.scss']
})
export class GenericReportDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
