export class EmployeeSearchReqdData {
  public firstName: string;
  public lastName: string;
  public globalId: string;
  public emailId: string;
  public phoneNumber: any;
}
